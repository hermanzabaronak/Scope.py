string = ' An apple a day keeps the doctor away'
key = {i:string.count(i) for i in string}
print(key)